import ROOT as r
import math

r.gROOT.Reset()
print 'First example:'
print 'Sqrt of 2 = '+str(math.sqrt(2.))


