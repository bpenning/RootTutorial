{
  gRoot->Reset();
  cout << "Example 1: "<<endl;
  cout << "Srqt of 2 = "<<sqrt(2.)<<endl;
}

