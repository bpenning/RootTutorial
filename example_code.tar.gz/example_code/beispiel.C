{
  gRoot->Reset();
  cout << "Example 1: "<<endl;
  cout << "Sqrt of 2 = "<<sqrt(2.)<<endl;
}

